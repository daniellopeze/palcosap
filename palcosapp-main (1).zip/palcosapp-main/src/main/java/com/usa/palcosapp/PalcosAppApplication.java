package com.usa.palcosapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PalcosAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(PalcosAppApplication.class, args);
	}

}
