package com.usa.palcosapp.repository.crudrepository;

import com.usa.palcosapp.model.Box;
import org.springframework.data.repository.CrudRepository;

public interface BoxCrudRepository extends CrudRepository<Box, Integer> {
}
