package com.usa.palcosapp.repository.crudrepository;

import com.usa.palcosapp.model.Category;
import org.springframework.data.repository.CrudRepository;

public interface CategoryCrudRepository extends CrudRepository<Category, Integer> {
}
