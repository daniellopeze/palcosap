package com.usa.palcosapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PalcosAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
